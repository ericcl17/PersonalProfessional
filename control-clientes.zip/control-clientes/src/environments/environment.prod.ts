export const environment = {
  production: true,
  firestore:{
    apiKey: "AIzaSyA3g9xnmA2PRgcEaAfOfU_3lTCVhVNvCLs",
    authDomain: "control-clientes-807ee.firebaseapp.com",
    databaseURL: "https://control-clientes-807ee.firebaseio.com",
    projectId: "control-clientes-807ee",
    storageBucket: "control-clientes-807ee.appspot.com",
    messagingSenderId: "747447602423",
    appId: "1:747447602423:web:479e8e8b48906404"
  }
};
