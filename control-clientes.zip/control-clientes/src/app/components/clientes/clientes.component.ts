import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ClienteService } from 'src/app/servicios/cliente.service';
import { Cliente } from 'src/app/model/cliente.model';
import { FlashMessagesService } from 'angular2-flash-messages';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-clientes',
  templateUrl: './clientes.component.html',
  styleUrls: ['./clientes.component.css']
})
export class ClientesComponent implements OnInit {
  clientes:Cliente[];
  cliente:Cliente={
    nombre:'',
    apellido:'',
    email:'',
    saldo:0
  };

  @ViewChild('clienteForm') clienteForm:NgForm;
  @ViewChild('btnClose') btnclose:ElementRef;

  constructor(private clienteService:ClienteService, private flashMsn:FlashMessagesService) { }

  ngOnInit() {
    this.clienteService.getClientes().subscribe(
      clientes => {
        this.clientes=clientes;
      }
    )
  }

  getSaldoTotal():number{
    let saldoTotal:number=0;
    if(this.clientes!=null){
      this.clientes.forEach(cliente =>{
        saldoTotal+=cliente.saldo;
      });
    }
    return saldoTotal;
  }

  agregar({value, valid}:{value:Cliente,valid:boolean}){
    if(!valid){
      this.flashMsn.show("Llenar formulario correctamente", {
        cssClass: 'alert-danger', timeout: 4000
      });
    }else{
      this.clienteService.agregarCliente(value);
      this.clienteForm.resetForm();
      this.cerrarModal();
    }
  }

  private cerrarModal(){
    this.btnclose.nativeElement.click();
  }

}
