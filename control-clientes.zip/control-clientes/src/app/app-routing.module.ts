import { NgModule } from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import { TableComponent } from './components/table/table.component';
import { LoginComponent } from './components/login/login.component';
import { RegistroComponent } from './components/registro/registro.component';
import { ConfiguracionComponent } from './components/configuracion/configuracion.component';
import { NoFoundComponent } from './components/no-found/no-found.component';
import { EditarClienteComponent } from './components/editar-cliente/editar-cliente.component';

const routes: Routes=[
  {path: '',component:TableComponent},
  {path: 'login',component:LoginComponent},
  {path: 'registro',component:RegistroComponent},
  {path: 'configuracion',component:ConfiguracionComponent},
  {path: 'cliente/editar/:id',component:EditarClienteComponent},
  {path: '**',component:NoFoundComponent},
]

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
