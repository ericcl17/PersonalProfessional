package com.bbva.efi;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EfiApplicationTests {


}
