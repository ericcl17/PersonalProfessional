package com.bbva.efi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.bbva.controller")
public class EfiApplication {

	public static void main(String[] args) {
		SpringApplication.run(EfiApplication.class, args);
	}

}
