package com.bbva.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.bbva.model.Person;

@Controller
@RequestMapping("/say")
public class HelloController {
	
	@GetMapping("/hello")
	public ModelAndView hey() {
		ModelAndView mov=new ModelAndView("HeWord");
		mov.addObject("persons",getlist());
		return mov;
	}
	
	private List<Person> getlist(){
		List<Person> per=new ArrayList<>();
		per.add(new Person("Eric",23));
		per.add(new Person("Lety",20));
		per.add(new Person("Fernando",23));
		return per;
	}
}
