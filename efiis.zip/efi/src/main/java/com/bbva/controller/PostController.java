package com.bbva.controller;

import com.bbva.model.Person;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

@Controller
@RequestMapping("/person")
public class PostController {
	
	//Redirect
	@GetMapping("/")
	public RedirectView redirect(){
		return new RedirectView("/person/register");
	}

	@GetMapping("/register")
	public String showForm(Model model) {
		model.addAttribute("employee", new Person());
		return "Form";
	}

	@PostMapping("/addPerson")
	public ModelAndView addPerson(@ModelAttribute("employee") Person person){
		ModelAndView mov = new ModelAndView("ResultPost");
		mov.addObject("person", person);
		return mov;
	}


}
