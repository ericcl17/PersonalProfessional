package com.bbva.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/new")
public class SecondController {

	// Petición get
	// request?nm=eric
	@GetMapping("/request")
	public ModelAndView request1(@RequestParam(name = "nm") String name) {
		ModelAndView mov = new ModelAndView("Request");
		mov.addObject("nm_mv", name);
		return mov;
	}

	// Petición get segunda forma
	// request/eric
	@GetMapping("/request2/{nm}")
	public ModelAndView request2(@PathVariable("nm") String name) {
		ModelAndView mov = new ModelAndView("Request");
		mov.addObject("nm_mv", name);
		return mov;
	}
}
