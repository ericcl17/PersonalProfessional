import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Person } from './personas/persona/persona.model';
import { LoginService } from './login/login.service';

@Injectable()
export class DataService{
    pathDB:string="https://listado-personas-a151b.firebaseio.com/data.json";
    constructor(private httpclient:HttpClient,private loginn:LoginService){}

    agregarPerson(persona:Person[]){
        const token=this.loginn.getIdToken();
        this.httpclient.put(this.pathDB+"?auth="+token,persona).subscribe(
            response => console.log(response),
            error => console.log(error)
        );
    }

    getPerson(){
        const token=this.loginn.getIdToken();
        return this.httpclient.get(this.pathDB+"?auth="+token);
    }

    modificarPerson(index:number,persona:Person){
        const token=this.loginn.getIdToken();
        let url:string=`https://listado-personas-a151b.firebaseio.com/data/${index}.json?auth=${token}`;
        this.httpclient.put(url,persona).subscribe(
            response => console.log(response)
        );
    }

    eliminarPerson(index:number){
        const token=this.loginn.getIdToken();
        let url:string=`https://listado-personas-a151b.firebaseio.com/data/${index}.json?auth=${token}`;
        this.httpclient.delete(url).subscribe(
            response => console.log(response)
        );
    }
}