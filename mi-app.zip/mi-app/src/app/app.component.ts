import { Component, OnInit} from '@angular/core';
import * as firebase from 'firebase';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  //personas:Person[]=[];
  constructor(){}

  ngOnInit():void{
    //this.personas=this.personasService.personas;
    firebase.initializeApp({
      apiKey: "AIzaSyBJnOHPVKLJQhmbYRHQx_6O8n-7jg0AK_A",
      authDomain: "listado-personas-a151b.firebaseapp.com",
    });
  }

}
