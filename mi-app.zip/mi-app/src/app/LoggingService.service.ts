export class LoggingService{
  recibirMensaje(mensaje:String){
    console.log(mensaje);
  }
}
