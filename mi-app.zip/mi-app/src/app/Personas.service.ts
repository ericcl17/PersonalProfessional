import { Person } from './personas/persona/persona.model';
import { LoggingService } from './LoggingService.service';
import { Injectable, EventEmitter } from '@angular/core';
import { DataService } from './Data.service';

//Decorador para inyectar un servicio dentro de otro
@Injectable()
export class PersonasService{
  personas:Person[]=[];
  saludar=new EventEmitter<string>();

  constructor(private loggingService:LoggingService, private dataService:DataService){}

  agregarPersona(persona:Person){
    if(this.personas==null){
      this.personas=[];
      this.personas.push(persona);
      this.dataService.agregarPerson(this.personas);
    }else{
      this.personas.push(persona);
      this.dataService.agregarPerson(this.personas);
    }
    
  }
  
  getPerson(){
    return this.dataService.getPerson();
  }

  setPerson(personas:Person[]){
    this.personas=personas;
  }

  findPerson(index:number){
    let persona:Person = this.personas[index];
    return persona;
  }

  modificar(index:number,nombre:string,apellido:string){
    let persona = this.personas[index];
    persona.nombre=nombre;
    persona.apellido=apellido;
    this.dataService.modificarPerson(index,persona);
  }

  eliminar(index:number){
    this.personas.splice(index,1);
    this.dataService.eliminarPerson(index);
    this.regenerarPersonas();
  }

  regenerarPersonas(){
    if(this.personas!=null){
        this.dataService.agregarPerson(this.personas);
    }
  }
}
