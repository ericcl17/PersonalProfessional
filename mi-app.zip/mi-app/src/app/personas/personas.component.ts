import { Component, OnInit } from '@angular/core';
import { Person } from './persona/persona.model';
import { PersonasService } from '../Personas.service';
import { Router } from '@angular/router';
import { LoginService } from '../login/login.service';

@Component({
  selector: 'app-personas',
  templateUrl: './personas.component.html',
  styleUrls: ['./personas.component.css']
})
export class PersonasComponent implements OnInit {

  personas: Person[] = [];
  constructor(private personasService: PersonasService, private router: Router, private loginn: LoginService) { }

  ngOnInit(): void {
    //this.personas=this.personasService.personas;
    this.personasService.getPerson().subscribe(
      (personas: Person[]) => {
        this.personas = personas;
        this.personasService.setPerson(personas);
      }
    );
  }

  agregar() {
    this.router.navigate(['personas/agregar']);
  }

  isAuth() {
    return this.loginn.isAuth();
  }

  logout() {
    this.loginn.logout();
  }

}
