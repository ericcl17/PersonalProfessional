import { Component, Input } from '@angular/core';
import { Person } from './persona.model';
import { PersonasService } from '../../Personas.service';

@Component({
  selector: 'app-persona',
  templateUrl: './persona.component.html',
  styleUrls: ['./persona.component.css']
})

export class PersonaComponent {
  @Input() personas:Person;

  constructor(private personasService:PersonasService){}

  enviarMSN(){
    this.personasService.saludar.emit("Hola amigos");
  }

  delete(index:number){
    this.personasService.eliminar(index);
  }
}
