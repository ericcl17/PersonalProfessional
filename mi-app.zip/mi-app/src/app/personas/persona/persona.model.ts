export class Person{
  constructor(public nombre:string,public apellido:string){}
}
