import { Component, EventEmitter, Output, ViewChild, ElementRef } from '@angular/core';
import { Person } from '../../personas/persona/persona.model';
import { PersonasService } from '../../Personas.service';
import { Router, ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-formulario',
  templateUrl: './formulario.component.html',
  styleUrls: ['./formulario.component.css']
})

export class FormularioComponent {
  constructor(private personasService:PersonasService, private router:Router, private route:ActivatedRoute){
    this.personasService.saludar.subscribe((msn:string) => alert(msn));
  }

  //@Output() personaCreada = new EventEmitter<Person>();
  nombre:string;
  apellido:string;
  index:number;

  //Local reference con ViewChild
  // @ViewChild('nombre') nombre: ElementRef;
  // @ViewChild('apellido') apellido: ElementRef;

  ngOnInit(){
    this.index=this.route.snapshot.params['id'];
    if(this.index){
      let persona:Person=this.personasService.findPerson(this.index);
      this.nombre=persona.nombre;
      this.apellido=persona.apellido;
    }
  }

  onAgregarPersona(){
    if(this.index){
      this.personasService.modificar(this.index,this.nombre,this.apellido);
    }else{
      this.personasService.agregarPersona(new Person(this.nombre,this.apellido));
    }
    this.router.navigate(['personas']);
    //this.personasService.agregarPersona(new Person(this.nombre.nativeElement.value,this.apellido.nativeElement.value));
    //this.personaCreada.emit(new Person(this.nombre.nativeElement.value,this.apellido.nativeElement.value));
  }

}
