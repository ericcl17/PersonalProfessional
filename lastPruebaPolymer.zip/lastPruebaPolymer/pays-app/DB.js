class DBConnect {
    connectDB() {
        return firebase.database().ref("data");
    }
}

