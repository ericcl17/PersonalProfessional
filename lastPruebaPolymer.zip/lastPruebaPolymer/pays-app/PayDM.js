class PayDM{
    addPay(pay){
        let db=new DBConnect().connectDB();
        db.push(pay);  
    }
}