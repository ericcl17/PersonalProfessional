import { Component, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-form-calculadora',
  templateUrl: './form-calculadora.component.html'
})
export class FormCalculadoraComponent {
  @Output() resultado = new EventEmitter<Number>();
  num1:number;
  num2:number;

  onSuma():void{
    this.resultado.emit(this.num1+this.num2);
  }
}
