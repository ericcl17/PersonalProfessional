export class Pay{
  constructor(public descripcion:string,public valor:number){}
}
