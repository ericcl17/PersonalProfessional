import { Pay } from '../model/Pay.model';

export class PayService{
  pays:Pay[]=[];
  paysEgress:Pay[]=[];

  addPays(pay:Pay,selectedPay:string){
    if(selectedPay=="ing"){
      this.pays.push(pay);
    }
    if(selectedPay=="egr"){
      this.paysEgress.push(pay);
    }
  }

  deletePay(i:number){
    this.pays.splice(i,1);
  }

  deletePayEgress(i:number){
    this.paysEgress.splice(i,1);
  }
}
