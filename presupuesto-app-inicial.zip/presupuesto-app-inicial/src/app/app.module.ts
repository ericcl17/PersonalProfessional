import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {PayService} from './services/Pay.service';
import { FormsModule }   from '@angular/forms';

import { AppComponent } from './app.component';
import { HeaderComponent } from './components/header/header.component';
import { FormComponent } from './components/form/form.component';
import { IngressComponent } from './components/ingress/ingress.component';
import { EgressComponent } from './components/egress/egress.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FormComponent,
    IngressComponent,
    EgressComponent
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [PayService],
  bootstrap: [AppComponent]
})
export class AppModule { }
