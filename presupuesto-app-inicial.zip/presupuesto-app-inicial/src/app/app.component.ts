import { Component, OnInit } from '@angular/core';
import { Pay } from './model/Pay.model';
import { PayService } from './services/Pay.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements OnInit{
  pays:Pay[]=[];
  paysEgress:Pay[]=[];

  constructor(private payService:PayService){
    this.pays=payService.pays;
    this.paysEgress=payService.paysEgress;
  }

  getIngressTotal(){
    let sumPays:number=0;
    this.pays.forEach(pay => {
      sumPays+=parseFloat(pay.valor);
    });
    return sumPays;
  }

  getEgressTotal(){
    let sumPaysEgress:number=0;
    this.paysEgress.forEach(pay => {
      sumPaysEgress+=parseFloat(pay.valor);
    });
    return sumPaysEgress;
  }

  getAvailable(){
    return this.getIngressTotal() - this.getEgressTotal();
  }

  getPercentage(){
    return this.getEgressTotal()/this.getIngressTotal()*100;
  }

  ngOnInit():void{}
}
