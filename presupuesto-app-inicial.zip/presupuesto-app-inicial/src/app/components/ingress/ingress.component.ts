import { Component, OnInit, Input } from '@angular/core';
import {Pay} from '../../model/Pay.model';
import {PayService} from '../../services/Pay.service';

@Component({
  selector: 'app-ingress',
  templateUrl: './ingress.component.html'
})
export class IngressComponent implements OnInit {
  @Input() pays:Pay;

  constructor(private payService:PayService){}

  ngOnInit() {
  }

  eliminar(index:number){
    this.payService.deletePay(index);
  }

}
