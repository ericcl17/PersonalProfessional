import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { PayService } from '../../services/Pay.service';
import {Pay} from '../../model/Pay.model';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html'
})

export class FormComponent implements OnInit {
  @ViewChild("descripcion") descripcion:ElementRef;
  @ViewChild("valor") valor:ElementRef;
  @ViewChild("selectedPay") selectedPay:ElementRef;

  constructor(private payService:PayService) { }

  ngOnInit() {
  }

  addPay(){
    this.payService.addPays(new Pay(this.descripcion.nativeElement.value,this.valor.nativeElement.value),this.selectedPay.nativeElement.value);
  }

}
