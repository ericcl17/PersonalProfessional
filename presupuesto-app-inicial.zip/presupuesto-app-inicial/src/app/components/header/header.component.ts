import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html'
})
export class HeaderComponent implements OnInit {
  @Input() sumPays:number;
  @Input() sumPaysEgress:number;
  @Input() available:number;
  @Input() percentage:number;

  constructor() { }

  ngOnInit() {
  }

}
