import { Component, OnInit, Input } from '@angular/core';
import {Pay} from '../../model/Pay.model';
import {PayService} from '../../services/Pay.service';

@Component({
  selector: 'app-egress',
  templateUrl: './egress.component.html'
})
export class EgressComponent implements OnInit {
  @Input() paysEgress:Pay;

  constructor(private payService:PayService){}

  ngOnInit() {
  }

  eliminar(index:number){
    this.payService.deletePayEgress(index);
  }

}
