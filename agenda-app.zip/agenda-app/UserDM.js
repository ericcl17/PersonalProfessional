class UserDm{
  constructor(name,email,phone,is,notes,image){
    this.name=name;
    this.email=email;
    this.phone=phone;
    this.is=is;
    this.notes=notes;
    this.image=image;
  }

  addUser(user){
    let res=true;
    let listUsers=[];
    listUsers = JSON.parse(window.localStorage.getItem('users'));
    if(listUsers==null){
      let listUser=[];
      listUser.push(user);
      window.localStorage.setItem('users',JSON.stringify(listUser));
    }else{
      //validar si ya existe el usuario
      if(listUsers.some(u => u.is!=user.is)){
        listUsers.push(user);
        window.localStorage.setItem('users',JSON.stringify(listUsers));
      }else{
        res=false;
      }
      return res;
    }
  }

  getAll(){
    return window.localStorage.getItem('users');
  }

  update(user){
    let listUsers= JSON.parse(window.localStorage.getItem('users'));
    let indexUser=listUsers.findIndex(u => u.is == user.is);
    listUsers.splice(indexUser,1); 
    listUsers.splice(indexUser,0,user);
    window.localStorage.setItem('users',JSON.stringify(listUsers));
    return listUsers;
  }

  delete(userIndex){
    let listUsers = JSON.parse(window.localStorage.getItem('users'));
    listUsers.splice(userIndex,1);
    window.localStorage.setItem('users',JSON.stringify(listUsers));
    return listUsers;
  }
}
